# Python-Flask-Blog
This is a flask based blog whose frontend is created using bootstrap.
If you have any questions or suggestions, feel free to open an issue or pull request :)
# My_First_Blog
